<?php
session_start();

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Koneksi ke database 'unite'
$host = 'localhost';
$dbname = 'unite';
$username = 'root';
$password = '';

try {
    // Koneksi ke database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES 'utf8'");
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    die();
}

// Ambil data user dari database berdasarkan session
$stmt = $pdo->prepare('SELECT * FROM users WHERE user_id = ?');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Proses update profil jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $username = $_POST['username'] ?? null;
    $email = $_POST['email'] ?? null;
    $phone = $_POST['phone'] ?? null;
    $profileImage = $_FILES['profile_image'] ?? null;

    // Check if required fields are set
    if ($username && $email && $phone) {
        // Folder upload untuk gambar profil
        $uploadDir = 'uploads/';
        $uploadFile = $uploadDir . basename($profileImage['name']);

        // Cek apakah folder upload ada, jika tidak buat folder tersebut
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Proses upload file jika ada file gambar yang dipilih
        if ($profileImage && $profileImage['error'] == UPLOAD_ERR_OK) {
            if (move_uploaded_file($profileImage['tmp_name'], $uploadFile)) {
                // Jika berhasil upload, update data pengguna termasuk gambar profil
                $stmt = $pdo->prepare('UPDATE users SET name = ?, email = ?, phone = ?, profile_image = ? WHERE user_id = ?');
                $stmt->execute([$username, $email, $phone, $uploadFile, $_SESSION['user_id']]);
            } else {
                $error = 'Gagal mengunggah gambar.';
            }
        } else {
            // Jika tidak ada file yang dipilih, hanya update data pengguna tanpa gambar
            $stmt = $pdo->prepare('UPDATE users SET name = ?, email = ?, phone = ? WHERE user_id = ?');
            $stmt->execute([$username, $email, $phone, $_SESSION['user_id']]);
        }

        // Perbarui session username
        $_SESSION['username'] = $username;

        // Redirect ke halaman utama setelah update
        header('Location: index.php');
        exit();
    } else {
        $error = 'Silakan lengkapi semua field yang diperlukan.';
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Edit Profile</h2>
    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
        <label for="username">Username</label><br>
        <input type="text" name="username" value="<?php echo htmlspecialchars($user['name']); ?>" required><br><br>

        <label for="email">Email</label><br>
        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required><br><br>

        <label for="phone">Phone</label><br>
        <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required><br><br>

        <label for="profile_image">Profile Image</label><br>
        <input type="file" name="profile_image" accept="image/*"><br><br>

        <button type="submit" name="update" class="submit-btn">Update Profile</button>
    </form>
    <br>
    <a href="index.php">Kembali ke Beranda</a>
</body>
</html>
