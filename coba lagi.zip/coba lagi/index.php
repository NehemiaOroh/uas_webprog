<?php
// Periksa apakah session sudah dimulai
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Koneksi ke database 'unite'
$host = 'localhost';
$dbname = 'unite'; // nama database 'unite'
$username = 'root'; // username MySQL
$password = ''; // password MySQL (kosong di XAMPP)

try {
    // Koneksi ke database 'unite'
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES 'utf8'");
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Logout handler
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}

// Cek apakah user sudah login
$isLoggedIn = isset($_SESSION['user_id']);
$profileImage = 'default.png'; // Gambar default

if ($isLoggedIn) {
    // Ambil data user dari database
    $stmt = $pdo->prepare('SELECT * FROM users WHERE user_id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    if ($user && !empty($user['profile_image'])) {
        $profileImage = $user['profile_image'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Page</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .profile-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }
        .visible {
            display: block;
        }
        .profile-dropdown {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background-color: white;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            padding: 10px;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">
            <img src="gambar1.jpg" alt="Logo" class="logo-icon">
            <span>Impresive</span>
        </div>
        <ul class="nav-links">
            <li><a href="#">Tentang Impresive</a></li>
            <li><a href="#">Layanan</a></li>
            <li><a href="#">Hubungi Kami</a></li>
        </ul>
        <div class="nav-actions">
            <div class="language">
                <span>🌐</span> ID
            </div>
            <?php if ($isLoggedIn): ?>
                <div id="profile" class="profile" style="position: relative; cursor: pointer;">
                    <img src="<?php echo htmlspecialchars($profileImage); ?>" alt="Profile Icon" class="profile-icon">
                    <span><?php echo htmlspecialchars($user['name']); ?></span>
                    <div id="profileDropdown" class="profile-dropdown">
                        <p>Member Silver</p>
                        <li><a href="edit_profile.php">Edit Profile</a></li>
                        <li><a href="/event-register">Event Register</a></li>
                        <form method="POST">
                            <button name="logout" class="logout-btn">Keluar</button>
                        </form>
                    </div>
                </div>
            <?php else: ?>
                <a href="login.php" class="login">Masuk</a>
                <a href="register.php" class="register">Daftar</a>
            <?php endif; ?>
        </div>
    </nav>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const profile = document.getElementById('profile');
            const profileDropdown = document.getElementById('profileDropdown');

            if (profile) {
                profile.addEventListener('click', function() {
                    profileDropdown.classList.toggle('visible');
                });
            }
        });
    </script>
</body>
</html>
