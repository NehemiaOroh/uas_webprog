<?php
// Mulai session
session_start();

// Koneksi ke database 'unite'
$host = 'localhost';
$dbname = 'unite'; // Nama database unite
$username = 'root'; // Username MySQL
$password = ''; // Password MySQL

try {
    // Koneksi ke database menggunakan PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Proses registrasi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $name = $_POST['name']; // Ambil nama dari form
    $email = $_POST['email']; // Ambil email dari form
    $password = $_POST['password']; // Ambil password dari form
    $confirm_password = $_POST['confirm_password']; // Ambil konfirmasi password
    $phone = $_POST['phone']; // Ambil nomor telepon

    // Validasi password dan konfirmasi password harus cocok
    if ($password !== $confirm_password) {
        $_SESSION['error'] = "Password dan Konfirmasi Password tidak cocok!";
        header('Location: register.php');
        exit();
    }

    // Enkripsi password sebelum menyimpannya di database
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Cek apakah email sudah ada di database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    if ($stmt->fetch()) {
        $_SESSION['error'] = "Email sudah terdaftar!";
        header('Location: register.php');
        exit();
    }

    // Simpan user baru ke database
    $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password) VALUES (:name, :email, :phone, :password)");
    $stmt->execute([
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'password' => $hashed_password
    ]);

    // Redirect ke halaman login setelah berhasil registrasi
    $_SESSION['success'] = "Registrasi berhasil! Silakan login.";
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Register</title>
</head>
<body>

<header class="header" style="border: 5px black; border-bottom: 0.1px solid black;">
    <h1>Unite</h1>
    <nav class="navigation_">
        <a href="index.php" style="color: black;">Home</a>
        <a href="events.php" style="color: black;">Events</a>
        <a href="about.php" style="color: black;">About Us</a>
    </nav>
</header>

<div class="register-form" style="text-align: center; padding: 50px;">
    <h1>Register</h1>
    <?php if(isset($_SESSION['error'])): ?>
        <p style="color: red;"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
    <?php endif; ?>
    <?php if(isset($_SESSION['success'])): ?>
        <p style="color: green;"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></p>
    <?php endif; ?>
    <form action="register.php" method="POST">
        <input type="text" name="name" placeholder="Enter Your Name" required><br><br>
        <input type="email" name="email" placeholder="Enter Your Email" required><br><br>
        <input type="text" name="phone" placeholder="Enter Your Phone" required><br><br>
        <input type="password" name="password" placeholder="Enter Password" required><br><br>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required><br><br>
        <button type="submit" name="register" class="button">Register</button>
    </form>
</div>

</body>
</html>
